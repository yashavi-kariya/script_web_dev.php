<?php
$a=42;
echo "$a is answer to everything";
?>