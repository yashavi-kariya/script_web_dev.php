<?php
$word1="hello!";
$word2="how are you";
$word3="i am learning php";
echo $word1 . $word2 . $word3;
?>
