<?php
$text="this is the php script";
echo strlen($text);
?>