<?php
$firstname="john";
$lastname;"doe!";
$c=$firstname . $lastname;
echo "hello, $c";
?>
