<?php
echo "<a href=https://www.example.com/>Click Here</a>";
?>