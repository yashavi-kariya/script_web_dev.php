<?php
$name="john!";
$age="25";
echo  "hello, . $name . you are . $age . years old.";
?>