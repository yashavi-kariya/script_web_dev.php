<?php
$num1=42;
$str="hello";
echo "The value of . num1 . and str is . $str .";
?>
