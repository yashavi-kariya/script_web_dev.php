<?php
$a="my name is john ";
$b="and i am php dveloper";
$c=$a . $b;
echo $c;
?>

