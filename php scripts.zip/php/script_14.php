<style>
	#a1
	{
		display: flex;
	}
    #a2{
			margin-left: 2em;
			display: flex;
	}
	#a3{
			margin-left: 4em;
			display: flex;
	}
	</style>
<?php
echo "<ol>
			<li id=a1>line1</li>
			<li id=a2>line2</li>
			<li id=a3>line3</li>
			</ol>";			
?>