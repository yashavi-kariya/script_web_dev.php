<?php
$name="hello!,john";
echo $name;
?>
