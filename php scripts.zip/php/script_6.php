<?php
$x=10;
$y=15;
$x=$y;
echo $x;
?>
