<?php
echo "<ul>";
echo "<li> b.com </li>";
echo "<li> m.com </li>";
echo "<li> bca </li>";
?>
