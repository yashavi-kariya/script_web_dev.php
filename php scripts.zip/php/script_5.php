<?php
$num=42;
$text="hello!";
echo "the text is: . $num . and the text is $text";
?>
