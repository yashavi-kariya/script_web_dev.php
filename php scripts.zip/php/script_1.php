<?php
echo "hello,php!";
?>
